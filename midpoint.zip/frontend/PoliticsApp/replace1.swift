//
//  replace1.swift
//  PoliticsApp
//
//  Created by Ronald Jabouin on 11/23/22.
//

import SwiftUI

struct replace1: View {
    var body: some View {
        Text("Replace this view 1 ")
    }
}

struct replace1_Previews: PreviewProvider {
    static var previews: some View {
        replace1()
    }
}
