//
//  PoliticsAppApp.swift
//  PoliticsApp
//
//  Created by Ronald Jabouin on 11/18/22.
//

import SwiftUI

@main
struct PoliticsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
